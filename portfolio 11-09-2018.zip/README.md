# Portfolio
My personal portfolio website showcasing my programming projects and skills.
View it live at [https://www.kylegough.co.uk/](https://www.kylegough.co.uk/)

This is a project I will continuously update and improve to further my understanding with web technologies.

### Uses:
* HTML
* CSS
  * Sass
* JavaScript
  * jQuery
  * Materialize
  * Bootstrap (Old version)
* PHP 
